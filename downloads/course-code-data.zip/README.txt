课程代码与教学数据，源自大数据与管理决策基础课程仓库。安装：pip install -e .
运行：PYTHONPATH=src python -m bdm_decision.cases.week03_sql_kpi
部分文件为课程建设中的模板，详见网站程序目录。
