"""Feature engineering utilities."""

