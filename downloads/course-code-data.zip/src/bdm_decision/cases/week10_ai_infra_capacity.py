"""Reproduce the textbook's illustrative AI-service capacity comparison."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from math import isfinite


@dataclass(frozen=True)
class Workload:
    base_input_tokens: int = 1000
    retrieved_passages: int = 4
    tokens_per_passage: int = 350
    output_tokens: int = 300
    prefill_tokens_per_second: float = 6000.0
    decode_tokens_per_second: float = 70.0
    fixed_seconds: float = 0.5
    query_seconds: float = 0.6
    tool_seconds: float = 0.4

    def __post_init__(self) -> None:
        for name in ("base_input_tokens", "retrieved_passages", "tokens_per_passage",
                     "output_tokens"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a nonnegative integer")
        for name in ("prefill_tokens_per_second", "decode_tokens_per_second"):
            value = getattr(self, name)
            if not isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        for name in ("fixed_seconds", "query_seconds", "tool_seconds"):
            value = getattr(self, name)
            if not isfinite(value) or value < 0:
                raise ValueError(f"{name} must be finite and nonnegative")
        if self.occupied_seconds <= 0:
            raise ValueError("occupied_seconds must be positive")

    @property
    def input_tokens(self) -> int:
        return self.base_input_tokens + self.retrieved_passages * self.tokens_per_passage

    @property
    def occupied_seconds(self) -> float:
        return (self.fixed_seconds
                + self.input_tokens / self.prefill_tokens_per_second
                + self.output_tokens / self.decode_tokens_per_second
                + self.query_seconds + self.tool_seconds)


@dataclass(frozen=True)
class Deployment:
    cloud_input_per_million: float = 0.75
    cloud_output_per_million: float = 3.0
    cloud_query_per_request: float = 0.0002
    local_fixed_per_hour: float = 3.0
    local_variable_per_request: float = 0.0002
    local_slots: int = 4
    utilization_limit: float = 0.7

    def __post_init__(self) -> None:
        for name in ("cloud_input_per_million", "cloud_output_per_million",
                     "cloud_query_per_request", "local_fixed_per_hour",
                     "local_variable_per_request"):
            value = getattr(self, name)
            if not isfinite(value) or value < 0:
                raise ValueError(f"{name} must be finite and nonnegative")
        if (isinstance(self.local_slots, bool) or not isinstance(self.local_slots, int)
                or self.local_slots <= 0):
            raise ValueError("local_slots must be a positive integer")
        if not isfinite(self.utilization_limit) or not 0 < self.utilization_limit <= 1:
            raise ValueError("utilization_limit must be in (0, 1]")


def estimate(requests_per_hour: float, workload: Workload = Workload(),
             deployment: Deployment = Deployment()) -> dict[str, float | int | bool | None]:
    """Compare hourly costs subject to a mean-occupancy design limit.

    The slot is assumed occupied during query and tool waits. This is a
    capacity approximation, not a percentile-latency or availability model.
    """
    if not isfinite(requests_per_hour) or requests_per_hour < 0:
        raise ValueError("requests_per_hour must be finite and nonnegative")
    cloud_unit = ((workload.input_tokens * deployment.cloud_input_per_million
                   + workload.output_tokens * deployment.cloud_output_per_million) / 1_000_000
                  + deployment.cloud_query_per_request)
    local_unit = deployment.local_variable_per_request
    capacity = (3600 * deployment.local_slots * deployment.utilization_limit
                / workload.occupied_seconds)
    saving = cloud_unit - local_unit
    break_even = deployment.local_fixed_per_hour / saving if saving > 0 else None
    return {
        "requests_per_hour": requests_per_hour,
        "input_tokens": workload.input_tokens,
        "output_tokens": workload.output_tokens,
        "occupied_seconds": workload.occupied_seconds,
        "mean_slot_utilization": requests_per_hour * workload.occupied_seconds
                                 / (3600 * deployment.local_slots),
        "design_capacity_per_hour": capacity,
        "local_within_design_capacity": requests_per_hour <= capacity,
        "cloud_unit_usd": cloud_unit,
        "cloud_hourly_usd": requests_per_hour * cloud_unit,
        "local_hourly_usd": deployment.local_fixed_per_hour
                            + requests_per_hour * local_unit,
        "cost_break_even_per_hour": break_even,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--requests-per-hour", type=float, default=900.0)
    parser.add_argument("--retrieved-passages", type=int, default=4)
    args = parser.parse_args()
    workload = Workload(retrieved_passages=args.retrieved_passages)
    print(json.dumps({"assumptions": {"workload": asdict(workload),
                                       "deployment": asdict(Deployment())},
                      "estimate": estimate(args.requests_per_hour, workload)},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
