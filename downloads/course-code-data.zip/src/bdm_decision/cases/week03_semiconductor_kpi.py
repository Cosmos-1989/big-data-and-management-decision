"""Semiconductor manufacturing KPI case for SQL and dashboard teaching."""

from __future__ import annotations

import csv
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from statistics import median
from typing import Iterable


PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DATA = PROJECT_ROOT / "data" / "sample" / "semiconductor_kpi_daily.csv"


@dataclass(frozen=True)
class SemiconductorDailyRecord:
    production_date: date
    area: str
    work_center: str
    product_family: str
    lots_started: int
    lots_completed: int
    good_units: int
    total_units: int
    planned_minutes: float
    runtime_minutes: float
    downtime_minutes: float
    ideal_cycle_seconds: float
    units_processed: int
    avg_cycle_time_hours: float
    wip_lots: int
    orders_due: int
    orders_on_time: int
    rework_lots: int
    scrap_units: int


@dataclass(frozen=True)
class ManufacturingKpiSummary:
    area: str
    work_center: str
    rows: int
    yield_rate: float
    availability: float
    performance: float
    quality: float
    oee: float
    average_cycle_time_hours: float
    average_wip_lots: float
    otd: float
    rework_rate: float
    scrap_rate: float


def load_semiconductor_records(path: str | Path = DEFAULT_DATA) -> list[SemiconductorDailyRecord]:
    records: list[SemiconductorDailyRecord] = []
    with Path(path).open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            records.append(
                SemiconductorDailyRecord(
                    production_date=datetime.strptime(row["production_date"], "%Y-%m-%d").date(),
                    area=row["area"],
                    work_center=row["work_center"],
                    product_family=row["product_family"],
                    lots_started=int(row["lots_started"]),
                    lots_completed=int(row["lots_completed"]),
                    good_units=int(row["good_units"]),
                    total_units=int(row["total_units"]),
                    planned_minutes=float(row["planned_minutes"]),
                    runtime_minutes=float(row["runtime_minutes"]),
                    downtime_minutes=float(row["downtime_minutes"]),
                    ideal_cycle_seconds=float(row["ideal_cycle_seconds"]),
                    units_processed=int(row["units_processed"]),
                    avg_cycle_time_hours=float(row["avg_cycle_time_hours"]),
                    wip_lots=int(row["wip_lots"]),
                    orders_due=int(row["orders_due"]),
                    orders_on_time=int(row["orders_on_time"]),
                    rework_lots=int(row["rework_lots"]),
                    scrap_units=int(row["scrap_units"]),
                )
            )
    return records


def summarize_manufacturing_kpis(
    records: Iterable[SemiconductorDailyRecord],
) -> list[ManufacturingKpiSummary]:
    buckets: dict[tuple[str, str], dict[str, float]] = defaultdict(
        lambda: {
            "rows": 0.0,
            "good_units": 0.0,
            "total_units": 0.0,
            "planned_minutes": 0.0,
            "runtime_minutes": 0.0,
            "ideal_runtime_seconds": 0.0,
            "cycle_time_weighted": 0.0,
            "lots_completed": 0.0,
            "wip_lots": 0.0,
            "orders_due": 0.0,
            "orders_on_time": 0.0,
            "rework_lots": 0.0,
            "scrap_units": 0.0,
        }
    )
    for record in records:
        bucket = buckets[(record.area, record.work_center)]
        bucket["rows"] += 1
        bucket["good_units"] += record.good_units
        bucket["total_units"] += record.total_units
        bucket["planned_minutes"] += record.planned_minutes
        bucket["runtime_minutes"] += record.runtime_minutes
        bucket["ideal_runtime_seconds"] += record.ideal_cycle_seconds * record.units_processed
        bucket["cycle_time_weighted"] += record.avg_cycle_time_hours * record.lots_completed
        bucket["lots_completed"] += record.lots_completed
        bucket["wip_lots"] += record.wip_lots
        bucket["orders_due"] += record.orders_due
        bucket["orders_on_time"] += record.orders_on_time
        bucket["rework_lots"] += record.rework_lots
        bucket["scrap_units"] += record.scrap_units

    summaries: list[ManufacturingKpiSummary] = []
    for (area, work_center), bucket in buckets.items():
        yield_rate = _safe_divide(bucket["good_units"], bucket["total_units"])
        availability = _safe_divide(bucket["runtime_minutes"], bucket["planned_minutes"])
        performance = _safe_divide(
            bucket["ideal_runtime_seconds"],
            bucket["runtime_minutes"] * 60,
        )
        quality = yield_rate
        oee = availability * performance * quality
        summaries.append(
            ManufacturingKpiSummary(
                area=area,
                work_center=work_center,
                rows=int(bucket["rows"]),
                yield_rate=yield_rate,
                availability=availability,
                performance=performance,
                quality=quality,
                oee=oee,
                average_cycle_time_hours=_safe_divide(
                    bucket["cycle_time_weighted"],
                    bucket["lots_completed"],
                ),
                average_wip_lots=_safe_divide(bucket["wip_lots"], bucket["rows"]),
                otd=_safe_divide(bucket["orders_on_time"], bucket["orders_due"]),
                rework_rate=_safe_divide(bucket["rework_lots"], bucket["lots_completed"]),
                scrap_rate=_safe_divide(bucket["scrap_units"], bucket["total_units"]),
            )
        )
    return sorted(summaries, key=lambda summary: (summary.area, summary.work_center))


def rolling_kpis(
    records: Iterable[SemiconductorDailyRecord],
    window: int = 3,
) -> list[dict[str, object]]:
    if window <= 0:
        raise ValueError("window must be positive")
    grouped: dict[str, list[SemiconductorDailyRecord]] = defaultdict(list)
    for record in records:
        grouped[record.work_center].append(record)

    rows: list[dict[str, object]] = []
    for work_center, group in grouped.items():
        recent: deque[SemiconductorDailyRecord] = deque(maxlen=window)
        for record in sorted(group, key=lambda item: item.production_date):
            recent.append(record)
            good = sum(item.good_units for item in recent)
            total = sum(item.total_units for item in recent)
            on_time = sum(item.orders_on_time for item in recent)
            due = sum(item.orders_due for item in recent)
            rows.append(
                {
                    "production_date": record.production_date.isoformat(),
                    "work_center": work_center,
                    "rolling_yield": _safe_divide(good, total),
                    "rolling_otd": _safe_divide(on_time, due),
                    "window_rows": len(recent),
                }
            )
    return sorted(rows, key=lambda row: (str(row["work_center"]), str(row["production_date"])))


def manufacturing_watchlist(
    summaries: Iterable[ManufacturingKpiSummary],
    oee_threshold: float = 0.75,
) -> list[ManufacturingKpiSummary]:
    summary_list = list(summaries)
    if not summary_list:
        return []
    median_wip = median(summary.average_wip_lots for summary in summary_list)
    return [
        summary
        for summary in summary_list
        if summary.oee < oee_threshold and summary.average_wip_lots > median_wip
    ]


def render_semiconductor_kpi_report_markdown() -> str:
    records = load_semiconductor_records()
    summaries = summarize_manufacturing_kpis(records)
    watchlist = manufacturing_watchlist(summaries)

    lines = [
        "# Semiconductor Manufacturing KPI Report",
        "",
        "## Work-center summary",
        "",
        "| area | work_center | yield | availability | performance | OEE | cycle_time_hours | avg_wip | OTD |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for summary in summaries:
        lines.append(
            "| {area} | {work_center} | {yield_rate:.4f} | {availability:.4f} | "
            "{performance:.4f} | {oee:.4f} | {cycle:.2f} | {wip:.1f} | {otd:.4f} |".format(
                area=summary.area,
                work_center=summary.work_center,
                yield_rate=summary.yield_rate,
                availability=summary.availability,
                performance=summary.performance,
                oee=summary.oee,
                cycle=summary.average_cycle_time_hours,
                wip=summary.average_wip_lots,
                otd=summary.otd,
            )
        )
    lines.extend(["", "## Watchlist", ""])
    if watchlist:
        for summary in watchlist:
            lines.append(
                "- {work_center}: OEE={oee:.4f}, average WIP={wip:.1f}, "
                "cycle time={cycle:.2f} hours".format(
                    work_center=summary.work_center,
                    oee=summary.oee,
                    wip=summary.average_wip_lots,
                    cycle=summary.average_cycle_time_hours,
                )
            )
    else:
        lines.append("- no work center meets the current watchlist rule")
    lines.extend(
        [
            "",
            "## Management note",
            "",
            "The case links Yield, OEE, Cycle Time, WIP, and OTD to a manufacturing "
            "diagnosis workflow.  A low-OEE and high-WIP work center should be "
            "reviewed through equipment, capacity, maintenance, quality, delivery, "
            "and action records rather than a single KPI alone.",
        ]
    )
    return "\n".join(lines)


def _safe_divide(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator else 0.0


if __name__ == "__main__":
    print(render_semiconductor_kpi_report_markdown())
