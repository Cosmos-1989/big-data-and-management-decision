"""Data ingestion utilities."""

