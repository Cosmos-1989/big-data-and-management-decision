"""FastAPI service entry point."""

