"""Warehouse and metrics assets."""

